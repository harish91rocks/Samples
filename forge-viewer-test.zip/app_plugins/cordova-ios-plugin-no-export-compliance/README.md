# iOS No Export Compliance

This plugin set ITSAppUsesNonExemptEncryption to false in *-Info.plist file

## Installation

`$ cordova plugin add https://github.com/mikaoelitiana/cordova-ios-plugin-no-export-compliance.git`

or

`$ cordova plugin add cordova-ios-plugin-no-export-compliance`
