import {Injectable} from '@angular/core';
import {Constants} from '../model/constants';

declare const cordova: any;
const HTTPD_NOT_AVAILABLE: string = 'CorHttpd plugin not available/ready.';


@Injectable({
    providedIn: 'root'
})

export class HttpdService {
    public httpdURL: string = Constants.HTTPD_URL;
    private httpd: any;
    
    constructor() {
        this.httpd = (cordova && cordova.plugins && cordova.plugins.CorHttpd) ? cordova.plugins.CorHttpd : null;
    }

    public getHttpd(): string {
        return this.httpd;
    }

    public startServer(): Promise<string> {
        let _HttpdService: any = this;
        return new Promise((resolve, reject) => {
            if (_HttpdService.httpd) {
                // before start, check whether its up or not
                _HttpdService.httpd.getURL(function (url: string) {
                    if (url.length > 0) {
                        resolve(url);
                    } else {
                        /* wwwroot is the root dir of web server, it can be absolute or relative path
                         * if a relative path is given, it will be relative to cordova assets/www/ in APK.
                         * "", by default, it will point to cordova assets/www/, it's good to use 'htdocs' for 'www/htdocs'
                         * if a absolute path is given, it will access file system.
                         * "/", set the root dir as the www root, it maybe a security issue, but very powerful to browse all dir
                         */
                        _HttpdService.httpd.startServer({
                            'www_root': Constants.HTTPD_ROOT_PATH,
                            'port': Constants.HTTPD_PORT,
                            'localhost_only': true
                        }, function (url: string) {
                            // if server is up, it will return the url of http://<server ip>:port/
                            // the ip is the active network connection
                            // if no wifi or no cell, "127.0.0.1" will be returned.
                            resolve(url);
                            console.log("Access file from : " + Constants.HTTPD_ROOT_PATH + " with the url " + url);
                        }, function (error: any) {
                            console.error('failed to start server: ' + error);
                            reject(error);
                        });
                    }

                });
            } else {
                alert(HTTPD_NOT_AVAILABLE);
                reject(HTTPD_NOT_AVAILABLE)
            }
        });
    }
    public stopServer(): Promise<Boolean> {
        let _HttpdService: any = this;
        return new Promise((resolve, reject) => {
            if (_HttpdService.httpd) {
                // call this API to stop web server
                _HttpdService.httpd.stopServer(function () {
                    console.log('server is stopped.');
                    resolve(true);
                }, function (error: any) {
                    console.error('failed to stop server' + error);
                    reject(error);
                });
            } else {
                alert(HTTPD_NOT_AVAILABLE);
                reject(HTTPD_NOT_AVAILABLE);
            }
        });
    }
}
