import {Injectable} from '@angular/core';
import {Constants} from '../model/constants';

declare const window: any;
declare const FileTransfer: any;

@Injectable({
    providedIn: 'root'
})
export class DownloadModelFilesService {
    public fileTransfer: any;

    constructor() {
        if (typeof FileTransfer != 'undefined') {
            this.fileTransfer = new FileTransfer();
        }
    }

    public download(url: string): Promise<any> {
        let source = encodeURI(url);
        let target = Constants.BIM_DATA_DIRECTORY + Constants.URL_TO_FILE_PATH(url);
        return new Promise((resolve, reject) => {
            this.isFileExisting(target).then(entry => {
                resolve(entry);
            }, error => {
                this.fileTransfer.download(
                    source,
                    target,
                    function (entry: any) {
                        resolve(entry);
                    },
                    function (error: any) {
                        reject(error);
                    },
                    false,
                    {
                        //                headers: {
                        //                    "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
                        //                }
                    }
                );
            });
        });
    }

    public isFileExisting(url: string): Promise<any> {
        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(
                Constants.BIM_DATA_DIRECTORY + Constants.URL_TO_FILE_PATH(url),
                function (entry: any) {
                    resolve(entry);
                }, function (error: any) {
                    reject(error);
                });
        });
    }

    public deleteDirectory(url: string): Promise<any> {

        //        window.resolveLocalFileSystemURL(
        //            cordova.file.externalDataDirectory,
        //            function (dirEntry) {
        //                dirEntry.filesystem.root.getDirectory(
        //                    'resources/bim/models/https:',
        //                    {create: true, exclusive: false},
        //                    function (entry) {
        //                        console.log(entry);
        //                    },
        //                    function (error) {
        //                        console.error(error);
        //                    })
        //            }, function (error) {
        //                console.error(error);
        //            });

        return new Promise((resolve, reject) => {
            window.resolveLocalFileSystemURL(
                Constants.BIM_DATA_DIRECTORY + Constants.URL_TO_FILE_PATH(url),
                function (entry: any) {
                    entry.removeRecursively(function () {
                        resolve(entry);
                    }, function (error: any) {
                        reject(error);
                    });
                }, function (error: any) {
                    reject(error);
                });
        });
    }

}
