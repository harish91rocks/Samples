import {BimModel} from "../model/bim-model";
import {Constants} from "../model/constants";

export class OfflineDataService {
    public publicModels: BimModel[] = [
        {
            url: 'https://harish-dev.000webhostapp.com/Resource/view/d/_3D_.svf',
            name: 'Public',
            loadDefault: true
        }
    ];
    public localModels: BimModel[] = [
        {
            url: Constants.HTTPD_URL + Constants.URL_TO_FILE_PATH('https://harish-dev.000webhostapp.com/Resource/view/d/_3D_.svf'),
            name: 'Public',
            loadDefault: true
        }
    ];
    constructor() {}
}