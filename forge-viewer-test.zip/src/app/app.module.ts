import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import { FormsModule }   from '@angular/forms';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {AssetListComponent} from './asset-list/asset-list.component';
import {ViewerComponent} from './viewer/viewer.component';
import {OfflineDataService} from './service/offline-data-service';
import {HttpdService} from './service/httpd.service';
import {DownloadModelFilesService} from './service/download-model-files.service';

@NgModule({
    declarations: [
        AppComponent,
        AssetListComponent,
        ViewerComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule
    ],
    providers: [OfflineDataService, HttpdService, DownloadModelFilesService],
    bootstrap: [AppComponent]
})
export class AppModule {}
