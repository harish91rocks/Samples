import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {BimModel} from './model/bim-model';
import {OfflineDataService} from './service/offline-data-service';
import {DownloadModelFilesService} from './service/download-model-files.service';
import {Constants} from './model/constants';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
    bimModelURL: string = 'https://harish-dev.000webhostapp.com/Resource/view/d/_3D_.svf';
    modelFilesToBeDownloaded: Array<string> = ["_3D_.svf", "1/mats/sitework.planting.grass.staugustine.bump1.jpg", "1/mats/sitework.planting.grass.staugustine.bump2.jpg", "1/mats/sitework.planting.grass.staugustine2.jpg", "3/mats/sitework.planting.grass.staugustine.bump1.jpg", "3/mats/sitework.planting.grass.staugustine.bump2.jpg", "3/mats/sitework.planting.grass.staugustine1.jpg", "3/mats/sitework.planting.grass.staugustine2.jpg", "3/mats/brick_uniform_running_bump.png", "3/mats/brick_uniform_running_burgundy.png", "3/mats/finishes.gypsum board.painted.white.bump.jpg", "3/mats/finishes.gypsum board.painted.white.jpg", "3/mats/masonry.stone.granite.square.stacked.polished.black.png", "mats/stone/external.dependency/simple_stone_mtl_granite_bump.jpg", "mats/stone/external.dependency/simple_stone_mtl_marble_bump.jpg", "mats/stone/external.dependency/simple_stone_mtl_stonewall_bump.jpg", "3/mats/woods&plastics.finishcarpentry.wood.beech.bump.jpg", "3/mats/woods&plastics.finishcarpentry.wood.beech.jpg", "3/mats/cmu_running_200x400_bump.png", "3/mats/autodesk.wood.plywood.png", "3/mats/finishes.plaster.stucco.fine.white.bump.png", "mats/concrete/external.dependency/simple_concrete_mtl_broomcurved_pattern.jpg", "mats/concrete/external.dependency/simple_concrete_mtl_broomstraight_pattern.jpg", "3/mats/woods & plastics.finish carpentry.wood.teak.png", "mats/metal/external.dependency/simple_metal_mtl_break_pattern.jpg", "mats/metal/external.dependency/simple_metal_mtl_brush_pattern.jpg", "mats/metal/external.dependency/simple_metal_mtl_checkerplate_pattern.jpg", "mats/metal/external.dependency/simple_metal_mtl_diamondplate_pattern.jpg", "3/mats/woods & plastics.finish carpentry.wood.red birch.png", "3/mats/concrete.precast structural concrete.smooth.jpg", "3/mats/woods&plastics.finishcarpentry.wood.spruce.bump.jpg", "3/mats/finishes.ceilings.acoustical tile.exposed grid.2x2.fissured.white.jpg", "3/mats/finishes.plaster.stucco.fine.white.bump.jpg", "3/mats/finishes.plaster.stucco.fine.white.jpg", "3/mats/metals.ornamental metals.chrome.satin.jpg", "3/mats/brick_uniform_soldier_bump.png", "3/mats/brick_uniform_soldier_burgundy.png", "2/mats/thermal - moisture.shingles.asphalt roofing.jpg", "3/mats/plastic_smooth_bump.png", "3/mats/sitework.planting.gravel.loose.bump.png", "3/mats/sitework.planting.gravel.loose.png", "2/mats/tilesquarebump.png", "3/mats/finishes.flooring.carpet.saxony.herringbone.bump.jpg", "3/mats/finishes.flooring.carpet.saxony.herringbone.jpg", "3/mats/metals.ornamental metals.aluminum.brushed.random.png", "3/mats/metals.ornamental metals.plate.mesh.cutout.png", "3/mats/finishes.flooring.tile.square.grey.dark.bump.jpg", "3/mats/finishes.flooring.tile.square.grey.dark.jpg", "3/mats/woods - plastics.finish carpentry.wood.pine.bump.jpg", "3/mats/doors - windows.door hardware.chrome.satin.jpg", "3/mats/metals.metal fabrications.metal stairs.galvanized.png", "3/mats/concrete.blocks.bump.png", "3/mats/concrete.blocks.png", "../../objects_attrs.json.gz", "../../objects_vals.json.gz", "../../objects_ids.json.gz", "../../objects_viewables.json.gz", "../../objects_offs.json.gz", "../../objects_avs.json.gz", "../../objects_rcv_offs.json.gz", "../../objects_rcvs.json.gz", "ProteinMaterials.json.gz", "Materials.json.gz", "CameraDefinitions.bin", "LightDefinitions.bin", "0.pf", "1.pf", "GeometryMetadata.pf", "FragmentList.pack", "CameraList.bin", "LightList.bin", "InstanceTree.bin", "embed:/metadata.json", "Set.bin"];

    title = 'forge-viewer-test';
    isActive = false;
    message: string;
    public bimModels: BimModel[];
    public offlineData: OfflineDataService;
    constructor(private router: Router, offlineData: OfflineDataService, public downloadModelFilesService: DownloadModelFilesService) {
        this.offlineData = offlineData;
    }

    public gotoAssetList(): void {
        this.router.navigate(['/asset-list']);
    }
    ngOnInit() {
    }

    public togglePublicModel() {
        this.bimModels = this.offlineData.publicModels;
        this.isActive = !this.isActive;
    }

    public toggleLocalModel() {
        this.bimModels = this.offlineData.localModels;
        this.isActive = !this.isActive;
    }

    public downloadBaseModel(): void {
        let thisObj = this;
        let bimModelURLObj = thisObj.bimModelURL;
        if (bimModelURLObj.endsWith('.svf')) {
            thisObj.message = 'Downloading model files of ' + bimModelURLObj;
            this.downloadModelFilesService.download(bimModelURLObj).then(function () {
                let sourceZip = Constants.BIM_DATA_DIRECTORY + Constants.URL_TO_FILE_PATH(bimModelURLObj);
                var sourceZipReq = new XMLHttpRequest();
                sourceZipReq.open("GET", sourceZip, true);
                sourceZipReq.responseType = "arraybuffer";
                sourceZipReq.onload = function () {
                    var arrayBuffer = sourceZipReq.response; // Note: not oReq.responseText
                    if (arrayBuffer) {
                        Constants.JSZIP.loadAsync(new Uint8Array(arrayBuffer)).then(function (zipObj: any) {
                            zipObj.file('manifest.json')
                                .async('string').then((text: string) => {
                                    let assets: Array<Object> = JSON.parse(text)['assets'];
                                    thisObj.downloadBIMAssets(bimModelURLObj, assets);
                                });
                        });
                    }
                };
                sourceZipReq.send(null);
            }).catch(error => {
                thisObj.message = 'Error : ' + JSON.stringify(error);
                console.error(error);
            });
        } else {
            alert('Invalid BIM model url.');
        }
    }

    private downloadBIMAssets(url: string, bimAssetsToBeDownloaded: Array<Object>) {
        url = url.substr(0, url.lastIndexOf("/") + 1);
        let thisObj = this;
        let fileCount = 0, totalFiles = bimAssetsToBeDownloaded.length;
        thisObj.message = "Downloaded files' (" + fileCount + "/" + totalFiles + ")";
        bimAssetsToBeDownloaded.forEach((modelFile: any) => {
            this.downloadModelFilesService.download(url + modelFile.URI).then(function () {
                fileCount++;
                thisObj.message = `Downloaded files  (${fileCount}/${totalFiles})`;
                if ((fileCount + 1) == totalFiles) {
                    thisObj.message = `${fileCount} files downloaded.`;
                }
            }).catch(error => {
                fileCount++;
                thisObj.message = 'Error : ' + JSON.stringify(error);
                if ((fileCount + 1) == totalFiles) {
                    thisObj.message = `${fileCount} files downloaded.`;
                }
                console.error(error);
            });
        });
    }

    public downloadModel() {
        let thisObj = this;
        let fileCount = 0, totalFiles = thisObj.modelFilesToBeDownloaded.length;
        thisObj.message = "Downloaded files' (" + fileCount + "/" + totalFiles + ")";
        this.modelFilesToBeDownloaded.forEach((modelFile, index) => {
            this.downloadModelFilesService.download("https://harish-dev.000webhostapp.com/Resource/view/d/" + modelFile).then(function () {
                fileCount++;
                thisObj.message = `Downloaded files  (${fileCount}/${totalFiles})`;
                if ((index + 1) == totalFiles) {
                    thisObj.message = `${fileCount} files downloaded.`;
                }
            }).catch(error => {
                thisObj.message = 'Error : ' + JSON.stringify(error);
                console.error(error);
            });
        });
    }

    public deleteModel() {
        let thisObj = this;
        thisObj.message = "Removing downloaded model files.";
        this.downloadModelFilesService.deleteDirectory('https://harish-dev.000webhostapp.com/Resource').then(function () {
            thisObj.message = "Removed downloaded model files.";
        }).catch(error => {
            thisObj.message = 'Error : ' + JSON.stringify(error);
            console.error(error);
        });
        //        thisObj.message += "'Downloading files ' (" + index + "/" + totalFiles + ")";


    }

}
