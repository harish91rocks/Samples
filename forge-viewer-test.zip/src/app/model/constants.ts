/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import {Injectable} from '@angular/core';

declare const cordova: any;
declare const JSZip: any;

@Injectable()
export class Constants {
    public static readonly JSZIP=JSZip;
    
    public static readonly DATA_DIRECTORY: string = (typeof cordova != 'undefined')?cordova.file.dataDirectory:"";
    public static readonly BIM_DATA_DIRECTORY: string = Constants.DATA_DIRECTORY + 'resources/bim/models/';
    public static readonly HTTPD_ROOT_PATH: string = Constants.BIM_DATA_DIRECTORY.replace('file://', '');
    public static readonly HTTPD_PORT: number = 8888;
    public static readonly HTTPD_URL: string = "http://localhost:" + Constants.HTTPD_PORT + "/";
    public static readonly URL_TO_FILE_PATH: Function = function (url: string) {return url.replace(/\\/g, "/").replace(/\/\//g, "/").replace(/:/g, '');};
}
