export interface Asset {
    id?: number;
    code?: string;
    name?: string;
    description?: string;
    tag?: string;
    strength?: number;
    bimModels?: string[];
  }