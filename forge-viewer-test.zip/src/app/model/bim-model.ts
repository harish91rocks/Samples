export interface BimModel {
  url: string;
  name: string;
  loadDefault: boolean;
}